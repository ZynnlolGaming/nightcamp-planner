const $=s=>document.querySelector(s);
const st=(t,c)=>{ $('#st').textContent=t; $('#st').className=c||''; };
const DEFAULT_URL='https://zynnlolgaming.github.io/nightcamp-planner/';
chrome.storage.local.get('plannerUrl').then(r=>{ $('#url').value=r.plannerUrl||DEFAULT_URL; });
$('#url').addEventListener('change',e=>chrome.storage.local.set({plannerUrl:e.target.value.trim()}));
let lastCode='';
$('#go').addEventListener('click',async()=>{
  $('#go').disabled=true; st('Reading your character…');
  try{
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab||!/^https:\/\/play\.nightcamp\.app\//.test(tab.url||'')){ st('Open the Night Camp game tab first, then click this again.','bad'); return; }
    const [res]=await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:ncExportBuild});
    const r=res&&res.result;
    if(!r||r.error){ st(r?r.error:'Could not read the game.','bad'); return; }
    lastCode=r.code; $('#code').value=r.code; $('#code').hidden=false;
    const s=r.summary; $('#sum').hidden=false;
    $('#sum').textContent=`${s.job||'?'} · Lv ${s.lv??'?'} · Job Lv ${s.jobLv??'?'} · ${s.skills} skills · ${s.runes} runes · ${s.items} items${s.stats?'':' · stats not found'}`;
    try{ await navigator.clipboard.writeText(r.code); st('Copied! Paste it into the planner’s Import window.','ok'); }
    catch(e){ $('#code').select(); st('Select the code below and copy it (Ctrl+C).','ok'); }
    $('#open').hidden=!$('#url').value.trim();
  }catch(e){ st('Error: '+e.message,'bad'); }
  finally{ $('#go').disabled=false; }
});
$('#url').addEventListener('input',()=>{ $('#open').hidden=!lastCode||!$('#url').value.trim(); });
$('#open').addEventListener('click',()=>{ const u=$('#url').value.trim(); if(u&&lastCode) chrome.tabs.create({url:u.split('#')[0]+'#ncb='+lastCode}); });
