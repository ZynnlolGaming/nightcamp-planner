# Night Camp Build Export

Tiny read-only Chrome/Edge/Brave extension. One button copies your current Night Camp build as a code (`NCB1.…`) that the Night Camp Build Planner can import.

**What's in the code:** class, Base/Job level, stat allocation, skill levels, runes per skill, equipped item IDs, and the game's own (Thai) names for those skills/items.
**What's not:** character name, account/player ID, coins, inventory, party, chat.

It only runs when you click the button, on `play.nightcamp.app`. It listens for one game snapshot (the same `nightcamp:online-snapshot` event the game already broadcasts), reads it, and stops. It never sends anything to the game server or changes the page.

## Install (developer mode)
1. Unzip this folder somewhere permanent.
2. Open `chrome://extensions` (or `edge://extensions`, `brave://extensions`) and turn on **Developer mode**.
3. Click **Load unpacked** and pick this folder.
4. Pin the extension, open the game, enter your character, click the icon → **Copy build code**.
5. In the planner: **📷 Import** → paste the code.

Optional: put your planner's web address in the popup to get an **Open in planner** button.

Credits: the game event names and rune format were learned from *Night Camp Telemetry*.
