/* Night Camp build exporter — runs inside the game page (MAIN world), read-only.
 * Listens for one 'nightcamp:online-snapshot' (the same event the game already broadcasts),
 * picks out build data only (no name, id, coins, chat, party) and returns a short code. */
async function ncExportBuild(){
  const NC=window.NC;
  if(!NC) return {error:'Night Camp is not loaded in this tab. Open play.nightcamp.app and enter the game first.'};
  const self=await new Promise(res=>{
    let done=false;
    const h=e=>{ const s=e&&e.detail&&e.detail.snapshot&&e.detail.snapshot.self; if(s&&!done){ done=true; window.removeEventListener('nightcamp:online-snapshot',h); res(s); } };
    window.addEventListener('nightcamp:online-snapshot',h);
    setTimeout(()=>{ if(!done){ done=true; window.removeEventListener('nightcamp:online-snapshot',h); res(null); } },4000);
  });
  const P=(NC.game&&NC.game.player)||null;
  const src=[self,P].filter(Boolean);
  if(!src.length) return {error:'No character data yet. Enter the game world (not the menu) and try again.'};
  const pick=k=>{ for(const o of src) if(o[k]!=null) return o[k]; return null; };
  const SK=['str','agi','vit','int','dex','luk'];
  // stat blocks: any object with all six stats (the smallest one is the allocation)
  const statC=[]; const seen=new Set();
  const walk=(o,path,d)=>{ if(!o||typeof o!=='object'||d>3||seen.has(o)) return; seen.add(o);
    if(SK.every(k=>typeof o[k]==='number')) statC.push({path,v:Object.fromEntries(SK.map(k=>[k,o[k]]))});
    for(const k of Object.keys(o).slice(0,300)){ const v=o[k]; if(v&&typeof v==='object'&&!Array.isArray(v)&&!/^(monsters|players|loot|mats|party|chat|inv|inventory|bag|mirrors)$/i.test(k)) walk(v,path+'.'+k,d+1); } };
  src.forEach((o,i)=>walk(o,i?'player':'self',0));
  // point counters: numeric fields named like points
  const pts={}; src.forEach(o=>Object.keys(o).forEach(k=>{ if(typeof o[k]==='number'&&/pt|point/i.test(k)&&!(k in pts)) pts[k]=o[k]; }));
  const num=v=>typeof v==='number'?v:(v&&typeof v==='object'?(v.lv??v.level??v.lvl??null):null);
  const skills={}; const rawSk=pick('skills')||{};
  for(const [k,v] of Object.entries(rawSk)){ const n=num(v); if(n!=null) skills[k]=n; }
  const equip={}; const rawEq=pick('equip')||{};
  for(const [k,v] of Object.entries(rawEq)){ const id=typeof v==='string'?v:(v&&(v.id||v.itemId))||null; if(id) equip[k]=id; }
  const bl=pick('buildLoot')||{}; const runes={};
  if(bl.runes&&typeof bl.runes==='object') for(const [k,v] of Object.entries(bl.runes)) if(Array.isArray(v)) runes[k]=v.map(x=>typeof x==='string'?x:null);
  const job=pick('job');
  const names={job:NC.JOBS&&NC.JOBS[job]?NC.JOBS[job].name:null,sk:{},it:{}};
  Object.keys(skills).concat(Object.keys(runes)).forEach(k=>{ const S=NC.SKILLS&&NC.SKILLS[k]; if(S&&S.name) names.sk[k]=S.name; });
  Object.values(equip).forEach(id=>{ const I=NC.ITEMS&&NC.ITEMS[id]; if(I&&I.name) names.it[id]=I.name; });
  // the game's own numbers: gear totals with your real rolls, final stats (base + gear + costume…), points left
  let gear=null, total=null, left=null, skLeft=null, skPts=null;
  try{ if(P&&typeof NC.gearStats==='function'){ const g=NC.gearStats.call(P,P.equip); if(g&&typeof g==='object'){ gear={}; for(const [k,v] of Object.entries(g)) if(typeof v==='number'&&v) gear[k]=Math.round(v*10000)/10000; } } }catch(e){}
  const dv=self&&self.derived; if(dv&&SK.every(k=>typeof dv[k]==='number')) total=Object.fromEntries(SK.map(k=>[k,dv[k]]));
  try{ if(P&&typeof NC.statusLeft==='function') left=NC.statusLeft(P); }catch(e){}
  try{ if(P&&typeof NC.skillLeft==='function') skLeft=NC.skillLeft(P); if(P&&typeof NC.skillPoints==='function') skPts=NC.skillPoints(P); }catch(e){}
  // each worn item as you actually have it: rolled stats (with ranges), grade (background colour), options and empty sockets
  let copies=null;
  try{ if(P&&NC.ItemRoll){ const R=NC.ItemRoll, bag=Array.isArray(P.bag)?P.bag:Object.values(P.bag||{}); copies={};
    for(const [sl,id] of Object.entries(P.equip||{})){ if(!id||/^(hair|fhat|frobe|tail)$/.test(sl)) continue; const it=NC.ITEMS&&NC.ITEMS[id]; if(!it) continue;
      const u=P.wu&&P.wu[sl], c=u?bag.find(x=>x&&x.u===u):null, o={id};
      try{ const st=R.statsFor(P.equip,sl,it)||{}; o.st={}; for(const [k,v] of Object.entries(st)) if(typeof v==='number'&&v) o.st[k]=v; }catch(e){}
      try{ o.lines=(R.lines(it,c||undefined)||[]).map(l=>({k:l.k,label:String(l.label||''),value:String(l.value||''),range:String(l.range||'')})); }catch(e){}
      if(c){ o.g=c.g||0; o.rows=(c.rows||[]).map(r=>{ let t=''; try{ t=String(NC.rowText(r)||'').replace(/<[^>]*>/g,''); }catch(e){} return {k:r.k,v:r.v,tier:r.tier||0,sub:r.sub||null,t}; }); }
      if(sl==='weapon'){ try{ const v=R.held(P); if(v&&Array.isArray(v.dmg)) o.dmg=v.dmg; }catch(e){} }
      copies[sl]=o; } } }catch(e){}
  let lore=null; // (the Lore Book: slots 7 / 8 and P1-P3 with each art's level; js/bl_arts.js BL.arts.got)
  try{ const A=NC.BL&&NC.BL.arts, G=(self&&self.arts&&self.arts.slots)?self.arts:(A&&A.got), lvOf=t=>{ try{ return A&&A.levelOf?A.levelOf(t):1; }catch(e){ return 1; } };
    if(G&&(G.slots||G.pas)) lore={act:(G.slots||[]).map(t=>t?[t,lvOf(t)]:null),pas:(G.pas||[]).map(t=>t?[t,lvOf(t)]:null),n:Object.keys(G.got||{}).filter(t=>(G.got[t]||0)>0).length}; }catch(e){}
  const base=self&&self.base&&SK.every(k=>typeof self.base[k]==='number')?Object.fromEntries(SK.map(k=>[k,self.base[k]])):null;
  const out={v:1,t:Date.now(),job,lv:pick('lv'),jobLv:pick('jobLv'),skills,equip,runes,lore,stats:statC.slice(0,6),pts,names,base,total,gear,left,skLeft,skPts,copies,
    keys:{self:self?Object.keys(self).slice(0,120):[],player:P?Object.keys(P).slice(0,120):[]}};
  const json=JSON.stringify(out);
  const b64=btoa(unescape(encodeURIComponent(json))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  return {code:'NCB1.'+b64,summary:{job:names.job||job,lv:out.lv,jobLv:out.jobLv,skills:Object.keys(skills).length,items:Object.keys(equip).length,runes:Object.values(runes).flat().filter(Boolean).length,stats:statC.length}};
}
